#!/usr/bin/env python
# coding=utf-8
# author: zengyuetian


import sys

if sys.version_info < (3, 0):   # 如果小于Python3
    PYTHON_3 = False
else:
    PYTHON_3 = True
