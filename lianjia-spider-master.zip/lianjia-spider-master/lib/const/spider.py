#!/usr/bin/env python
# coding=utf-8
# author: zengyuetian


thread_pool_size = 50
