#!/usr/bin/env python
# coding=utf-8
# author: zengyuetian

LIANJIA_SH_BASE_URL = "http://sh.lianjia.com"
ERSHOUFANG_BASE_URL = "http://sh.lianjia.com/ershoufang"
SH_XIAOQU_BASE_URL = 'http://sh.lianjia.com/xiaoqu'

